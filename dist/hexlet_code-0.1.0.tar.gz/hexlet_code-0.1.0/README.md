### Hexlet tests and linter status:
[![Actions Status](https://github.com/garryfisher/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/garryfisher/python-project-50/actions)
[![Lint status](https://github.com/garryfisher/python-project-50/workflows/make-lint/badge.svg)](https://github.com/garryfisher/python-project-50/actions)

<a href="https://codeclimate.com/github/garryfisher/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/df0c9295986e60cf71d0/maintainability" /></a>
<a href="https://codeclimate.com/github/garryfisher/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/df0c9295986e60cf71d0/test_coverage" /></a>

<h3>Comparison of the two JSON files</h3>
<a href="https://asciinema.org/a/ADM8hqMJkrRP0mfBwIE7xY8bQ" target="_blank"><img src="https://asciinema.org/a/ADM8hqMJkrRP0mfBwIE7xY8bQ.svg" /></a>

<h3>Comparison of the two YAML files</h3>
<a href="https://asciinema.org/a/9chYTq0FmpIazdz4qG8X1tUBS" target="_blank"><img src="https://asciinema.org/a/9chYTq0FmpIazdz4qG8X1tUBS.svg" /></a>
