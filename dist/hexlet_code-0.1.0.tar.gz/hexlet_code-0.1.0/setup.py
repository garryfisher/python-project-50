# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['argparse>=1.4.0,<2.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Project gendiff',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/garryfisher/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/garryfisher/python-project-50/actions)\n[![Lint status](https://github.com/garryfisher/python-project-50/workflows/make-lint/badge.svg)](https://github.com/garryfisher/python-project-50/actions)\n\n<a href="https://codeclimate.com/github/garryfisher/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/df0c9295986e60cf71d0/maintainability" /></a>\n<a href="https://codeclimate.com/github/garryfisher/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/df0c9295986e60cf71d0/test_coverage" /></a>\n\n<h3>Run programm</h3>\n<a href="https://asciinema.org/a/ADM8hqMJkrRP0mfBwIE7xY8bQ" target="_blank"><img src="https://asciinema.org/a/ADM8hqMJkrRP0mfBwIE7xY8bQ.svg" /></a>\n',
    'author': 'Gennady Vinogradov',
    'author_email': 'gwinogradow@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/garryfisher/python-project-50',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
